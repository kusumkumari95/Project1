﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement_System
{
        class Student : IStudent
        {
            string ClassName;
            public string Class
            {
                get
                {
                    return ClassName;
                }

                set
                {
                    ClassName = value;
                }
            }
        
            DateTime dateofBirth;
            public DateTime DateofBirth
            {
                get
                {
                    return dateofBirth;
                }

                set
                {
                    dateofBirth = value;
                }
            }

            string fullName;
            public string FullName
            {
                get
                {
                    return fullName;
                }

                set
                {
                    fullName = value;
                }
            }

            int id;
            public int ID
            {
                get
                {
                    return id;
                }

                set
                {
                    id = value;
                }
            }


            string native;
            public string Native
            {
                get
                {
                    return native;
                }

                set
                {
                    native = value;
                }
            }

            int phoneNo;
            public int PhoneNo
            {
                get
                {
                    return phoneNo;
                }

                set
                {
                    phoneNo = value;
                }
            }

            public void Display()
            {
            Console.WriteLine("Id: " + id);
                Console.WriteLine("Full Name: " + FullName);
                Console.WriteLine("Date of Birth: " + DateofBirth.ToString("dd/MM/yyyy"));
                Console.WriteLine("Native: " + Native);
                Console.WriteLine("Class: " + Class);
                Console.WriteLine("Phone No : " + PhoneNo);
             
            }
        }
    }
