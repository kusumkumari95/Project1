﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement_System
{
    interface IStudent
    {

            int ID
            {
                get;
                set;
            }

            string FullName
            {
                get;
                set;
            }

            DateTime DateofBirth
            {
                get;
                set;
            }

            string Native
            {
                get;
                set;
            }

            string Class
            {
                get;
                set;
            }

          /*  string PhoneNo
            {
                get;
                set;
            }*/

            int PhoneNo
            {
                get;
                set;
            }

            void Display();
        }
    }


