﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement_System
{
    class Program
    {
         
            static Dictionary<int, Student> listDictionary = new Dictionary<int, Student>();
            static void Main(string[] args)
            {
                while (true)
                {
                    Console.WriteLine("+----------------------------+");
                    Console.WriteLine("| STUDENTS MANAGEMENT SYSTEM |");
                    Console.WriteLine("+----------------------------+");
                    Console.WriteLine("|1. Insert new Student       |");
                    Console.WriteLine("|2. View list of Students    |");
                    Console.WriteLine("|3. Search Students          |");
                    Console.WriteLine("|4. Exit                     |");
                    Console.WriteLine("+----------------------------+");
                    Console.Write("Your choice: ");
                    int choice = int.Parse(Console.ReadLine());
                    switch (choice)
                    {
                        case 1:
                            InsertStudent();
                            break;
                        case 2:
                            ViewList();
                            break;
                        case 3:
                            Search();
                            break;
                        case 4:
                            return;
                    }
                }
            }

           private static void Search()
            {
                bool found = false;
                Console.Write("Input Class: ");
                String search = Console.ReadLine();
                Console.WriteLine("All student of class " + search);
                foreach (Student student in listDictionary.Values)
                {
                    if (student.Class.Equals(search))
                    //if (String.Compare(student.Class, search, true) == 0)
                    {
                        Console.WriteLine("----------------------------");
                        student.Display();
                        found = true;
                    }
                }
                if (!found)
                {
                    Console.WriteLine("No students were found!");
                }
            }
      
        private static void ViewList()
            {
                foreach (Student i in listDictionary.Values)
                {
                    Console.WriteLine("----------------------------");
                    i.Display();
                }
            }

            private static void InsertStudent()
            {
                Student student = new Student();

                //Increament ID
                student.ID = listDictionary.Count + 1;

                //Input name
                Console.Write("Enter Fullname: ");
                student.FullName = Console.ReadLine();

                //Input date
                while (true)
                {
                    Console.Write("Enter Date of Birth: ");
                    DateTime dDate;
                    try
                    {
                        student.DateofBirth = DateTime.Parse(Console.ReadLine());
                        break;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("The date is not in the correct format!");
                        Console.WriteLine(ex.Message);
                    }
                }

                //Input Native
                Console.Write("Enter Native: ");
                student.Native = Console.ReadLine();

                //Input Class
                Console.Write("Enter Class: ");
                student.Class = Console.ReadLine();

                //Input Phone No
               // Console.Write("Enter Phone No: ");
                //student.PhoneNo = Console.ReadLine();

                //Input Mobile
                while (true)
                {
                    Console.Write("Enter Mobile: ");
                    try
                    {
                        student.PhoneNo =int.Parse(Console.ReadLine());
                        break;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("The number is not in the correct format!");
                        Console.WriteLine(ex.Message);
                    }
                }

                listDictionary.Add(student.ID, student);
                Console.WriteLine("Successfully inserted a student!");
            }
        }
    }

